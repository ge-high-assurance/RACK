from .GenerateSTK import autogen

autogen = autogen
